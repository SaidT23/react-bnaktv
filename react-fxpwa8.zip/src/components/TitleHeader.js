import React from 'react';
import '../style.css';

export default function TitleHeader() {
  return (
    <div className="container">
      <div className="texts">
        <h1 className="title">House of Cats</h1>
        <p className="description">
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry's standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it to make a type specimen book.
        </p>
        <p className="notes">
          It was popularised in the 1960s with the release of Letraset sheets
          containing Lorem Ipsum passages, and more recently with desktop
          publishing software like Aldus PageMaker including versions of Lorem
          Ipsum
        </p>
      </div>
      <div className="images">
        <img className="bigImage" src="https://placekitten.com/g/600/350" />
      </div>
    </div>
  );
}
