import React from 'react';
import '../style.css';

export default function Player() {
  return <h1>Player</h1>;
}
