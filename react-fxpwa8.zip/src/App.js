import React from 'react';
import './style.css';
import Home from './page/Home';
//import Login from './page/Login';
//import Player from './page/Player';

export default function App() {
  return <Home />;
}
