import React from 'react';
import '../style.css';

export default function VideoList() {
  return (
    <div>
      <h4>Lista dei vod</h4>
      <div className="scroll">
        <div className="thumbnail">
          <img src="https://placekitten.com/g/300/200" />
          <img src="https://placekitten.com/g/400/300" />
          <img src="https://placekitten.com/g/500/400" />
          <img src="https://placekitten.com/g/800/500" />
          <img src="https://placekitten.com/g/700/600" />
        </div>
      </div>
    </div>
  );
}
