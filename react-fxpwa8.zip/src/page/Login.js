import React from 'react';
import '../style.css';

export default function Login() {
  return <h1>Login</h1>;
}
